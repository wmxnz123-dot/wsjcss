const userButton=document.getElementById('managerUser');
const userMenu=document.getElementById('userMenu');
const sidebar=document.getElementById('managerSidebar');
const dashboard=document.getElementById('dashboardView');
const placeholder=document.getElementById('placeholder');
const placeholderTitle=document.getElementById('placeholderTitle');
userButton.addEventListener('click',event=>{event.stopPropagation();userMenu.hidden=!userMenu.hidden});
userMenu.addEventListener('click',event=>event.stopPropagation());
document.addEventListener('click',()=>userMenu.hidden=true);
document.getElementById('mobileMenu').addEventListener('click',()=>sidebar.classList.toggle('open'));
document.querySelectorAll('.group-title').forEach(button=>button.addEventListener('click',()=>{const group=button.closest('section'),open=!group.classList.contains('open');document.querySelectorAll('.manager-sidebar section').forEach(item=>item.classList.remove('open'));group.classList.toggle('open',open)}));
function showDashboard(){dashboard.hidden=false;placeholder.hidden=true;document.querySelectorAll('[data-view]').forEach(item=>item.classList.remove('active'));document.querySelector('[data-view="dashboard"]').classList.add('active');sidebar.classList.remove('open')}
document.querySelectorAll('[data-view]').forEach(button=>button.addEventListener('click',()=>{if(button.dataset.view==='dashboard'){showDashboard();return}document.querySelectorAll('[data-view]').forEach(item=>item.classList.remove('active'));button.classList.add('active');dashboard.hidden=true;placeholder.hidden=false;placeholderTitle.textContent=button.dataset.view;sidebar.classList.remove('open');window.scrollTo({top:0,behavior:'smooth'})}));
document.getElementById('backDashboard').addEventListener('click',showDashboard);
